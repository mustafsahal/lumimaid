"use client";
import { useEffect } from 'react';
import LeadForm from '@/components/LeadForm';
import { titleize } from '@/lib/seo';

export const metadata = {
  title: titleize('Book Your Clean'),
  description: 'Schedule your LumiMaid cleaning online in minutes.',
};

export default function BookPage() {
  const bookingLink = process.env.NEXT_PUBLIC_BOOKING_LINK;

  useEffect(() => {
    // Fire begin_checkout event when booking page loads or Calendly mounts.
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('begin_checkout'));
    }
  }, []);

  return (
    <main className="px-4 py-12">
      <div className="max-w-xl mx-auto text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-semibold mb-2">Book Your Clean</h1>
        <p className="text-slate-600">
          {bookingLink
            ? 'Select a time that works for you in the embedded calendar.'
            : 'Provide your details and we will confirm availability. We reply in under 10 minutes.'}
        </p>
      </div>
      {bookingLink ? (
        <div className="max-w-3xl mx-auto">
          <iframe
            src={bookingLink}
            className="w-full h-[700px] border border-slate-200 rounded"
            loading="lazy"
          ></iframe>
        </div>
      ) : (
        <div className="max-w-lg mx-auto">
          <LeadForm />
        </div>
      )}
    </main>
  );
}