/**
 * Generates Schema.org LocalBusiness structured data based on the site
 * configuration. This helps search engines understand the nature of the
 * business and can enable rich results.
 */
export function localBusinessSchema(cfg: any) {
  return {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: cfg.businessName,
    image: `https://${cfg.domain}/og/og-home.jpg`,
    telephone: cfg.primaryPhone,
    email: cfg.email,
    address: {
      '@type': 'PostalAddress',
      streetAddress: cfg.address,
      addressLocality: cfg.city,
      addressRegion: 'MN',
      postalCode: '',
      addressCountry: 'US',
    },
    areaServed: cfg.serviceAreas,
    openingHours: 'Mo-Su 07:00-19:00',
    url: `https://${cfg.domain}/`,
    priceRange: '$$',
  };
}