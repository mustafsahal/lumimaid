import { useState } from 'react';

export interface FAQItem {
  q: string;
  a: string;
}
export interface FAQProps {
  items: FAQItem[];
}

/**
 * FAQ displays a list of frequently asked questions with simple
 * expand/collapse toggles. This improves readability and SEO by
 * exposing structured content.
 */
export default function FAQ({ items }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  return (
    <div className="space-y-4">
      {items.map((item, idx) => {
        const open = openIndex === idx;
        return (
          <div key={idx} className="border-b border-slate-200 pb-4">
            <button
              type="button"
              className="w-full flex justify-between items-center text-left"
              onClick={() => setOpenIndex(open ? null : idx)}
            >
              <span className="font-medium text-brand-dark">{item.q}</span>
              <span className="text-brand-primary">{open ? '-' : '+'}</span>
            </button>
            {open && (
              <p className="mt-2 text-sm text-slate-700">{item.a}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}