"use client";
import Link from 'next/link';

export interface HeroProps {
  headline: string;
  subheadline: string;
  bullets: string[];
  ctaPrimary: string;
  ctaSecondary: string;
  promo: string;
}

/**
 * The hero section of the homepage. Displays a compelling headline,
 * supporting bullets and prominent calls to action. It also includes
 * a promo badge to highlight special offers.
 */
export default function Hero({
  headline,
  subheadline,
  bullets,
  ctaPrimary,
  ctaSecondary,
  promo,
}: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-brand-dark text-white py-16 px-4 lg:px-8">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-dark to-brand-primary opacity-80"></div>
      <div className="relative max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <h1 className="text-3xl md:text-5xl font-semibold leading-tight">
            {headline}
          </h1>
          <p className="text-lg md:text-xl text-brand-accent/90">
            {subheadline}
          </p>
          <ul className="space-y-2">
            {bullets.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-brand-accent">✔</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            <Link
              href="#lead"
              className="inline-block px-6 py-3 rounded bg-brand-accent text-brand-dark font-medium text-center"
            >
              {ctaPrimary}
            </Link>
            <Link
              href="/book"
              className="inline-block px-6 py-3 rounded border border-brand-accent text-brand-accent font-medium text-center"
            >
              {ctaSecondary}
            </Link>
          </div>
          {promo && (
            <p className="mt-4 italic text-brand-accent/80 text-sm">
              {promo}
            </p>
          )}
        </div>
        <div className="hidden md:block">
          {/* Preload a hero image; you can swap sample-1.jpg with your own image */}
          <img
            src="/gallery/sample-1.jpg"
            alt="A pristine living space after LumiMaid cleaning"
            className="rounded-lg shadow-lg w-full h-auto object-cover"
            loading="eager"
          />
        </div>
      </div>
    </section>
  );
}