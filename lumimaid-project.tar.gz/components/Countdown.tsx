"use client";
import { useEffect, useState } from 'react';

/**
 * Countdown shows the number of days left in the current month. Used
 * to create urgency around limited availability. If you prefer a static
 * note you can adjust this component accordingly.
 */
export default function Countdown() {
  const [daysLeft, setDaysLeft] = useState<number | null>(null);
  useEffect(() => {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const diff = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    setDaysLeft(diff);
  }, []);
  if (daysLeft === null) return null;
  return (
    <p className="text-sm text-brand-dark">
      Only {daysLeft} days left to secure your new-client promo this month!
    </p>
  );
}