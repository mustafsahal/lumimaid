import { titleize } from '@/lib/seo';
import services from '@/content/services.json';
import PackageCard from '@/components/PackageCard';
import CTA from '@/components/CTA';

export const metadata = {
  title: titleize(services.seo.title),
  description: services.seo.description,
};

export default function ServicesPage() {
  return (
    <main className="px-4 py-12">
      <div className="max-w-4xl mx-auto text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-semibold mb-2">{services.seo.title}</h1>
        <p className="text-slate-600">{services.intro}</p>
      </div>
      <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.services.map((svc) => (
          <PackageCard
            key={svc.slug}
            name={svc.name}
            promise={svc.promise}
            bullets={svc.benefits}
            priceFrom={svc.startingAt}
            cta={`Book ${svc.name.split(' ')[0]}`}
            href={`/book?service=${svc.slug}`}
          />
        ))}
      </div>
      <div className="max-w-3xl mx-auto mt-8 text-slate-600 text-sm text-center">
        {services.disclaimer}
      </div>
      <div className="mt-12">
        <CTA headline="Unsure which service fits?" button="Get a Quote" href="/book" />
      </div>
    </main>
  );
}