import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { MDXRemote } from 'next-mdx-remote/rsc';
import remarkGfm from 'remark-gfm';
import { titleize } from '@/lib/seo';

interface FrontMatter {
  title: string;
  excerpt: string;
  keywords?: string[];
}

// Generate static params for blog slugs
export async function generateStaticParams() {
  const blogDir = path.join(process.cwd(), 'content', 'blog');
  const files = fs.readdirSync(blogDir).filter((f) => f.endsWith('.mdx'));
  return files.map((file) => ({ slug: file.replace(/\.mdx$/, '') }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const filePath = path.join(process.cwd(), 'content', 'blog', `${params.slug}.mdx`);
  const raw = fs.readFileSync(filePath, 'utf-8');
  const { data } = matter(raw);
  const fm = data as FrontMatter;
  return {
    title: titleize(fm.title),
    description: fm.excerpt.slice(0, 155),
  };
}

export default async function BlogPost({ params }: { params: { slug: string } }) {
  const filePath = path.join(process.cwd(), 'content', 'blog', `${params.slug}.mdx`);
  const source = fs.readFileSync(filePath, 'utf-8');
  const { content, data } = matter(source);
  const frontmatter = data as FrontMatter;
  return (
    <main className="px-4 py-12">
      <article className="prose prose-slate max-w-3xl mx-auto">
        <h1>{frontmatter.title}</h1>
        <MDXRemote source={content} options={{ mdxOptions: { remarkPlugins: [remarkGfm] } }} />
      </article>
    </main>
  );
}