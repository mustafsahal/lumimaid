/**
 * PostCSS configuration for the LumiMaid project.
 *
 * This file wires up Tailwind CSS and Autoprefixer as PostCSS
 * plugins. Tailwind will remove unused CSS based on the classes
 * referenced in your project files, and Autoprefixer will add vendor
 * prefixes where necessary to maximize browser compatibility.
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};