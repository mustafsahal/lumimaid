/**
 * Tailwind CSS configuration for the LumiMaid project.
 *
 * The `content` array tells Tailwind which files to scan for class
 * names. By including all files in the `app` directory, we ensure that
 * unused styles are purged from the final build, keeping the CSS
 * bundle lean. You can extend the default theme here if needed.
 */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
};