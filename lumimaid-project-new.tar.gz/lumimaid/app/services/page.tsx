import Link from 'next/link';

/**
 * Services page for LumiMaid. This page outlines the details of our
 * cleaning packages, offering a visual comparison between our Deep
 * Clean and Standard Clean options. It aims to educate visitors
 * and encourage them to book the package that fits their needs.
 */
export const metadata = {
  title: 'Cleaning Services | Deep & Standard Cleaning | LumiMaid',
  description:
    'Explore our Deep Clean and Standard Clean packages to find the perfect cleaning service for your Minneapolis home.',
};

export default function ServicesPage() {
  return (
    <main className="max-w-5xl mx-auto px-4 py-16 space-y-16">
      <section className="text-center space-y-6">
        <h1 className="text-4xl font-bold">Our Cleaning Services</h1>
        <p className="text-gray-600 max-w-3xl mx-auto">
          LumiMaid offers a range of cleaning options designed to fit your
          lifestyle. Whether you need a meticulous deep clean or a
          recurring maintenance service, our packages are tailored to
          deliver exceptional results.
        </p>
      </section>
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow space-y-4">
          <h2 className="text-2xl font-semibold">Deep Clean</h2>
          <p className="text-gray-700">
            Perfect for seasonal resets or preparing your home for special
            occasions. Our Deep Clean package includes comprehensive tasks
            that leave every nook and cranny sparkling.
          </p>
          <ul className="list-disc pl-5 space-y-1 text-gray-700">
            <li>Behind appliances, baseboards &amp; windowsills</li>
            <li>Inside cabinets, closets &amp; drawers</li>
            <li>Detailed scrubbing of kitchen &amp; bathroom surfaces</li>
            <li>High &amp; low dusting, including ceiling fans</li>
          </ul>
        </div>
        <div className="bg-white p-6 rounded-lg shadow space-y-4">
          <h2 className="text-2xl font-semibold">Standard Clean</h2>
          <p className="text-gray-700">
            Ideal for ongoing maintenance to keep your home tidy and fresh.
            This package focuses on the most commonly used areas of your
            home to maintain cleanliness without the need for a deep
            overhaul.
          </p>
          <ul className="list-disc pl-5 space-y-1 text-gray-700">
            <li>Dusting of furniture &amp; surfaces</li>
            <li>Vacuuming &amp; mopping of floors</li>
            <li>Cleaning of counters, sinks &amp; appliance exteriors</li>
            <li>Bathroom cleaning &amp; sanitation</li>
          </ul>
        </div>
      </section>
      <section className="text-center">
        <Link
          href="/book"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors"
        >
          Book Your Cleaning Now
        </Link>
      </section>
    </main>
  );
}