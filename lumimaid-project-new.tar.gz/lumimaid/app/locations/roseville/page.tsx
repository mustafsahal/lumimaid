export const metadata = {
  title: 'House Cleaning Roseville MN | Premium Maid Service | LumiMaid',
  description:
    'LumiMaid provides professional house cleaning in Roseville. Safe, eco-friendly cleaning with bonded and insured cleaners. 100% guarantee every time.',
};

export default function RosevillePage() {
  const city = 'Roseville';
  const neighborhoods = [
    'Lexington Park',
    'Lake Josephine',
    'Lake McCarrons',
    'Owasso Hills',
    'North Ridge',
  ];
  return (
    <main className="max-w-5xl mx-auto px-4 py-16 space-y-12">
      <section className="space-y-4 text-center">
        <h1 className="text-4xl font-bold">
          Luxury House Cleaning in {city}, MN
        </h1>
        <p className="text-gray-600">
          Trusted, bonded, and eco-friendly cleaning for {city} residents.
        </p>
      </section>
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold">Why Choose LumiMaid in {city}?</h2>
        <ul className="list-disc pl-6 space-y-2 text-gray-700">
          <li>Bonded &amp; Insured</li>
          <li>Eco-Friendly Products</li>
          <li>Background-Checked Professionals</li>
          <li>100% Happiness Guarantee</li>
        </ul>
      </section>
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold">Our Services</h2>
        <ul className="list-disc pl-6 space-y-2 text-gray-700">
          <li>Recurring Cleaning</li>
          <li>Deep Cleaning</li>
          <li>Move-In / Move-Out Cleaning</li>
          <li>Eco-Friendly Options</li>
          <li>Add-On Services (fridge, oven, windows, laundry)</li>
        </ul>
      </section>
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold">Testimonials</h2>
        <p className="italic text-gray-600">
          “Our {city} home has never looked better thanks to LumiMaid! – Local Client”
        </p>
      </section>
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold">
          Neighborhoods We Serve in {city}
        </h2>
        <ul className="list-disc pl-6 space-y-1 text-gray-700">
          {neighborhoods.map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      </section>
      <section className="text-center">
        <a
          href="/book"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
        >
          Get My Instant Quote
        </a>
      </section>
      <section className="space-y-4">
        <h2 className="text-3xl font-semibold">Trust LumiMaid</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Bonded">
              🛡️
            </span>
            <p className="mt-2 font-semibold">Bonded &amp; Insured</p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Eco-Friendly">
              🌿
            </span>
            <p className="mt-2 font-semibold">Eco-Friendly</p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Background">
              👩‍🔧
            </span>
            <p className="mt-2 font-semibold">Background-Checked</p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Guarantee">
              ✅
            </span>
            <p className="mt-2 font-semibold">100% Guarantee</p>
          </div>
        </div>
      </section>
    </main>
  );
}