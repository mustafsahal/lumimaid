/**
 * A simple before/after slider. Shows two images side by side on small
 * screens and overlapping with a draggable divider on larger screens.
 * For simplicity we just use a two-column layout with alt text. In a
 * production site you could enhance this with a real slider.
 */
export interface BeforeAfterProps {
  beforeSrc: string;
  afterSrc: string;
  caption?: string;
}

export default function BeforeAfter({ beforeSrc, afterSrc, caption }: BeforeAfterProps) {
  return (
    <div className="my-8">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <img
            src={beforeSrc}
            alt="Before cleaning"
            className="w-full h-auto rounded object-cover"
            loading="lazy"
          />
          <p className="text-center text-xs mt-1 text-slate-500">Before</p>
        </div>
        <div>
          <img
            src={afterSrc}
            alt="After cleaning"
            className="w-full h-auto rounded object-cover"
            loading="lazy"
          />
          <p className="text-center text-xs mt-1 text-slate-500">After</p>
        </div>
      </div>
      {caption && <p className="text-center mt-2 text-sm text-slate-600">{caption}</p>}
    </div>
  );
}