"use client";
import Link from "next/link";
import { useState } from "react";

/**
 * Sticky site header with responsive navigation and CTA.
 *
 * On desktop, displays inline nav links and a primary “Get a Quote” button.
 * On mobile, collapses into a hamburger menu that reveals the nav items
 * along with quick access to phone/email and the CTA. Events are dispatched
 * for GTM integration when users click the CTA or contact links.
 */
export default function Header() {
  const [open, setOpen] = useState(false);
  // Fire a custom event for GTM/analytics integrations
  const fire = (name: string, detail: any = {}) => {
    try {
      window.dispatchEvent(new CustomEvent(name, { detail }));
    } catch {
      /* no-op on server */
    }
  };
  // Primary navigation items
  const navItems = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About" },
    { href: "/blog", label: "Blog" },
    { href: "/locations/minneapolis", label: "Locations" },
    { href: "/book", label: "Book" },
  ];
  return (
    <header role="banner" className="sticky top-0 z-50 w-full bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center" aria-label="Go to homepage">
          <img
            src="/brand/logo.svg"
            alt="LumiMaid logo"
            className="h-8 w-auto"
          />
        </Link>
        {/* Desktop navigation */}
        <nav aria-label="Main" className="hidden md:flex space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-slate-700 hover:text-brand-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        {/* Desktop CTA */}
        <div className="hidden md:block">
          <Link href="/book" passHref>
            <button
              onClick={() => fire("begin_checkout", { source: "header" })}
              className="bg-brand-primary text-white px-4 py-2 rounded-md hover:bg-brand-dark"
            >
              Get a Quote
            </button>
          </Link>
        </div>
        {/* Mobile menu toggle */}
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="md:hidden p-2"
          aria-label="Toggle navigation menu"
        >
          <svg
            className="h-6 w-6 text-brand-dark"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={
                open
                  ? "M6 18L18 6M6 6l12 12"
                  : "M4 6h16M4 12h16M4 18h16"
              }
            />
          </svg>
        </button>
      </div>
      {/* Mobile nav panel */}
      {open && (
        <div className="md:hidden bg-white shadow-md">
          <nav aria-label="Mobile" className="px-4 pt-2 pb-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block py-2 text-slate-700"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            {/* Quick actions */}
            <div className="border-t border-slate-200 pt-2">
              <a
                href="tel:+16128887916"
                onClick={() => fire("contact", { type: "phone", source: "header" })}
                className="block py-2"
              >
                Call us
              </a>
              <a
                href="mailto:info@lumimaid.com"
                onClick={() => fire("contact", { type: "email", source: "header" })}
                className="block py-2"
              >
                Email us
              </a>
              <Link
                href="/book"
                onClick={() => {
                  fire("begin_checkout", { source: "header" });
                  setOpen(false);
                }}
                className="block py-2"
              >
                Get a Quote
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}