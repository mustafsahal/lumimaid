import Link from 'next/link';

// Simple site header with navigation links.
export default function Header() {
  const nav = [
    { href: '/', label: 'Home' },
    { href: '/services', label: 'Services' },
    { href: '/locations', label: 'Locations' },
    { href: '/contact', label: 'Contact' },
  ];
  return (
    <header className="border-b bg-white/80 backdrop-blur">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3">
        <Link href="/" className="font-semibold text-xl text-slate-900">
          LumiMaid
        </Link>
        <nav className="flex gap-6">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-slate-600 hover:text-slate-900"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
