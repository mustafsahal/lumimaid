import Link from 'next/link'
import site from '@/site.config.json'

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-cream/80 backdrop-blur">
      <div className="container flex items-center justify-between h-16">
        <Link href="/" className="font-serif text-2xl">
          {site.businessName}
        </Link>
        <nav className="hidden md:flex gap-6 items-center">
          <Link href="/services/weekly">Services</Link>
          <Link href="/what-to-expect">What to Expect</Link>
          <Link href="/policies-faq">Policies & FAQ</Link>
          <Link href="/service-areas/minneapolis">Service Areas</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/about-us">About</Link>
          <Link href="/gift-cards">Gift Cards</Link>
        </nav>
        <Link href="/book-now" className="btn btn-primary">Book Now</Link>
      </div>
    </header>
  )
}
