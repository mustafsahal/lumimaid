'use client'
import BookingForm from './BookingForm'

export default function BookingWidget() {
  const link = process.env.NEXT_PUBLIC_BOOKING_LINK
  if (link) {
    return (
      <div className="card">
        <div className="aspect-[16/10] w-full rounded-2xl overflow-hidden">
          <iframe
            src={link}
            className="w-full h-full"
            title="Booking"
            loading="lazy"
          />
        </div>
        <p className="text-xs opacity-70 mt-2">Powered by your booking provider.</p>
      </div>
    )
  }
  return <BookingForm />
}
