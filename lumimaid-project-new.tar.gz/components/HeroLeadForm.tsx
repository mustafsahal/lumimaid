"use client";
import { useState } from "react";

export default function HeroLeadForm() {
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState<boolean | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());

    if (typeof window !== "undefined") {
      (window as any).dataLayer = (window as any).dataLayer || [];
      (window as any).dataLayer.push({ event: "lead_form_submitted", payload });
    }

    setLoading(true);
    try {
      const res = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      setOk(res.ok);
    } catch {
      setOk(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="grid gap-3 sm:grid-cols-5 bg-white/80 backdrop-blur p-4 rounded-2xl shadow"
    >
      <input
        required
        name="name"
        placeholder="Name"
        className="sm:col-span-1 rounded-lg border p-3"
      />
      <input
        required
        name="zip"
        placeholder="ZIP"
        className="sm:col-span-1 rounded-lg border p-3"
      />
      <select name="service" className="sm:col-span-1 rounded-lg border p-3">
        <option>Standard</option>
        <option>Deep Clean</option>
        <option>Move In/Out</option>
        <option>Office</option>
      </select>
      <input
        required
        name="phone"
        placeholder="Phone"
        className="sm:col-span-1 rounded-lg border p-3"
      />
      <button
        type="submit"
        disabled={loading}
        className="sm:col-span-1 rounded-lg p-3 bg-black text-white hover:opacity-90"
      >
        {loading ? "Sending..." : "Get My Quote"}
      </button>
      {ok === true && (
        <p className="sm:col-span-5 text-green-700">
          Thanks! We’ll be in touch shortly.
        </p>
      )}
      {ok === false && (
        <p className="sm:col-span-5 text-red-700">
          Something went wrong. Please try again.
        </p>
      )}
    </form>
  );
}