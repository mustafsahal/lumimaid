import Link from 'next/link'
import { services } from '@/lib/services'

export default function ServicesGrid() {
  return (
    <section className="container py-10">
      <h2 className="font-serif text-3xl mb-6">Popular Services</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {services.slice(0,3).map(s => (
          <div key={s.slug} className="card">
            <h3 className="font-semibold text-lg">{s.title}</h3>
            <p className="opacity-80 mt-1">{s.excerpt}</p>
            <ul className="mt-4 list-disc ml-5 text-sm opacity-90">
              {s.features.slice(0,4).map(f => <li key={f}>{f}</li>)}
            </ul>
            <Link href={`/services/${s.slug}`} className="btn btn-primary mt-6">Book {s.title}</Link>
          </div>
        ))}
      </div>
    </section>
  )
}
