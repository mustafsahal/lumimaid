export interface TestimonialProps {
  name: string;
  area: string;
  quote: string;
  rating: number;
}

/**
 * Displays a customer testimonial with name, location and rating as
 * simple stars. Used on the home page to build trust.
 */
export default function Testimonial({ name, area, quote, rating }: TestimonialProps) {
  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-sm">
      <p className="text-sm text-slate-700 mb-4">“{quote}”</p>
      <div className="flex items-center justify-between">
        <div className="text-brand-dark font-medium">
          {name} • {area}
        </div>
        <div className="flex gap-1">
          {Array.from({ length: 5 }).map((_, idx) => (
            <span key={idx} className={idx < rating ? 'text-brand-primary' : 'text-slate-300'}>
              ★
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}