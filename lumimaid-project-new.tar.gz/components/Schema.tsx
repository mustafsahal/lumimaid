"use client";

type LocalBusinessParams = {
  name: string;
  phone: string;
  email?: string;
  url: string;
  logo?: string;
  street?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  country?: string;
  serviceAreas?: string[];
  priceRange?: string;
  openingHours?: string[];
  sameAs?: string[];
};

export function LocalBusinessSchema(p: LocalBusinessParams) {
  const {
    name,
    phone,
    email,
    url,
    logo = "/logo.png",
    street,
    city,
    region,
    postalCode,
    country = "US",
    serviceAreas = [
      "Minneapolis",
      "Edina",
      "St. Louis Park",
      "Bloomington",
    ],
    priceRange = "$$",
    openingHours = ["Mo-Fr 08:00-18:00", "Sa 09:00-15:00"],
    sameAs = [],
  } = p;

  const json = {
    "@context": "https://schema.org",
    "@type": "HouseCleaningService",
    name,
    telephone: phone,
    email,
    url,
    logo,
    priceRange,
    address: street
      ? {
          "@type": "PostalAddress",
          streetAddress: street,
          addressLocality: city,
          addressRegion: region,
          postalCode,
          addressCountry: country,
        }
      : undefined,
    areaServed: serviceAreas.map((a) => ({ "@type": "AdministrativeArea", name: a })),
    openingHours,
    sameAs,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(json) }}
    />
  );
}

export function FAQPageSchema(faq: { question: string; answer: string }[]) {
  const json = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faq.map(({ question, answer }) => ({
      "@type": "Question",
      name: question,
      acceptedAnswer: { "@type": "Answer", text: answer },
    })),
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(json) }}
    />
  );
}

export function BreadcrumbsSchema(items: { name: string; url: string }[]) {
  const json = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: it.url,
    })),
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(json) }}
    />
  );
}