"use client";
import Link from 'next/link';

/**
 * StickyBar stays fixed at the bottom of the viewport on mobile,
 * encouraging users to take action. It offers quick access to the
 * booking page or to call the business.
 */
export default function StickyBar() {
  return (
    <div className="fixed bottom-0 inset-x-0 bg-brand-primary text-white py-3 px-4 flex justify-between items-center md:hidden z-50">
      <span className="font-medium">Ready to book?</span>
      <div className="flex gap-3">
        <a
          href="tel:+16128887916"
          className="bg-brand-dark px-3 py-2 rounded text-xs"
          onClick={() => {
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('contact'));
            }
          }}
        >
          Call
        </a>
        <Link
          href="/book"
          className="bg-white text-brand-dark px-3 py-2 rounded text-xs"
        >
          Book
        </Link>
      </div>
    </div>
  );
}