"use client";
import Link from "next/link";

export default function StickyCTA() {
  const bookUrl = process.env.NEXT_PUBLIC_BOOKING_LINK || "/book";
  const onClick = () => {
    if (typeof window !== "undefined") {
      (window as any).dataLayer = (window as any).dataLayer || [];
      (window as any).dataLayer.push({
        event: "booking_started",
        source: "sticky_cta",
      });
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Link
        href={bookUrl}
        onClick={onClick}
        className="rounded-2xl px-5 py-3 shadow-lg bg-black text-white hover:opacity-90 transition"
        aria-label="Book a cleaning"
      >
        Get a Quote
      </Link>
    </div>
  );
}