import { services } from '@/lib/services'

export default function ComparisonTable() {
  return (
    <section className="container py-10">
      <h2 className="font-serif text-3xl mb-6">Compare Service Packages</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm bg-white rounded-2xl shadow-soft">
          <thead>
            <tr className="[&>th]:p-4 text-left">
              <th>Feature</th>
              {services.map(s => <th key={s.slug}>{s.title}</th>)}
            </tr>
          </thead>
          <tbody>
            <tr className="[&>td]:p-4 border-t">
              <td>Bedrooms/Bathrooms</td>
              {services.map(s => <td key={s.slug}>{s.includes.bedsBaths}</td>)}
            </tr>
            <tr className="[&>td]:p-4 border-t">
              <td>Kitchen & Appliances</td>
              {services.map(s => <td key={s.slug}>{s.includes.kitchen}</td>)}
            </tr>
            <tr className="[&>td]:p-4 border-t">
              <td>Floors & Baseboards</td>
              {services.map(s => <td key={s.slug}>{s.includes.floors}</td>)}
            </tr>
            <tr className="[&>td]:p-4 border-t">
              <td>Price Guidance</td>
              {services.map(s => <td key={s.slug}>{s.priceHint}</td>)}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  )
}
