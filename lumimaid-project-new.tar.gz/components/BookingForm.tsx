'use client'
import { useForm } from 'react-hook-form'
import { useState } from 'react'

type FormData = {
  name: string
  email: string
  phone: string
  address: string
  service: string
  date: string
  notes?: string
}

export default function BookingForm() {
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm<FormData>()
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const onSubmit = async (data: FormData) => {
    setError(null); setSuccess(null)
    try {
      const res = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      if (!res.ok) throw new Error('Failed to submit')
      setSuccess('Thanks! We received your request and will confirm shortly.')
      reset()
    } catch (e:any) {
      setError(e.message || 'Something went wrong')
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card">
      <h3 className="font-serif text-2xl mb-4">Request Your Cleaning</h3>
      <div className="grid md:grid-cols-2 gap-4">
        <input {...register('name', { required: true })} placeholder="Full name" className="input" />
        <input {...register('email', { required: true })} placeholder="Email" className="input" type="email" />
        <input {...register('phone', { required: true })} placeholder="Phone" className="input" />
        <input {...register('address', { required: true })} placeholder="Address" className="input" />
        <select {...register('service', { required: true })} className="input">
          <option value="">Select service</option>
          <option>Weekly</option>
          <option>Bi-Weekly</option>
          <option>Monthly</option>
          <option>Deep Clean</option>
          <option>Move-In/Out</option>
        </select>
        <input {...register('date', { required: true })} type="date" className="input" />
      </div>
      <textarea {...register('notes')} placeholder="Notes (pets, parking, special requests)" className="input mt-4" rows={4} />
      <button className="btn btn-primary mt-4" disabled={isSubmitting}>
        {isSubmitting ? 'Submitting...' : 'Submit Request'}
      </button>
      {success && <p className="mt-3 text-green-700">{success}</p>}
      {error && <p className="mt-3 text-red-700">{error}</p>}
      <style jsx>{`
        .input { @apply w-full rounded-xl border border-black/10 px-4 py-2; }
      `}</style>
    </form>
  )
}
