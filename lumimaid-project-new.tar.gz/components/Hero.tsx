import Link from 'next/link'

export default function Hero() {
  return (
    <section className="relative">
      <div className="container grid md:grid-cols-2 gap-10 py-20 items-center">
        <div>
          <h1 className="font-serif text-4xl md:text-5xl leading-tight">
            Elevate Your Minneapolis Home to a Sanctuary
          </h1>
          <p className="mt-4 text-lg opacity-80">
            Experience the pinnacle of luxury cleaning: meticulous detail, trusted
            professionals and eco‑friendly products to leave your home
            sparkling, serene and truly inviting. LumiMaid is committed to
            setting the gold standard for house cleaning in Minnesota.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/book-now" className="btn btn-primary">Get Your Instant Quote</Link>
            <Link href="/services/weekly" className="btn btn-secondary">View Services</Link>
          </div>
          <div className="mt-6 text-sm opacity-70">Bonded • Insured • 100% Happiness Guarantee</div>
        </div>
        <div className="card">
          <img
            src="/images/luxury-living.jpg"
            alt="Immaculate luxury living room"
            className="rounded-2xl w-full h-auto"
            />
        </div>
      </div>
    </section>
  )
}
