import Link from "next/link";

export default function InternalLinkingSection() {
  return (
    <section className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold">Popular Services</h2>
      <ul className="mt-3 grid gap-2 md:grid-cols-2">
        <li>
          <Link className="underline" href="/services/deep-cleaning">
            Deep cleaning in Minneapolis
          </Link>
        </li>
        <li>
          <Link className="underline" href="/services/move-in-out-cleaning">
            Move-out cleaning in Edina
          </Link>
        </li>
      </ul>
    </section>
  );
}