const items = [
  { name: 'Alyssa M., Edina', quote: 'Absolutely pristine. The attention to detail is unmatched.' },
  { name: 'Jordan P., Minneapolis', quote: 'Professional, punctual, and my home has never looked better.' },
  { name: 'Sam R., St. Louis Park', quote: 'Worth every penny—truly a luxury experience.' },
]

export default function Testimonials() {
  return (
    <section className="container py-10">
      <h2 className="font-serif text-3xl mb-6">What Clients Say</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map((t, i) => (
          <blockquote key={i} className="card">
            <p className="italic">“{t.quote}”</p>
            <div className="mt-3 text-sm opacity-70">— {t.name}</div>
          </blockquote>
        ))}
      </div>
    </section>
  )
}
