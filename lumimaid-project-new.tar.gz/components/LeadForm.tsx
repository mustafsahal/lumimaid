"use client";
import { useState, useEffect } from 'react';

export default function LeadForm() {
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    zip: '',
    service: '',
    preferredDate: '',
    notes: '',
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  // capture UTM and gclid from query string
  const [utm, setUtm] = useState<Record<string, string>>({});
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const fields = ['utm_source', 'utm_medium', 'utm_campaign', 'gclid'];
    const obj: Record<string, string> = {};
    fields.forEach((f) => {
      const val = params.get(f);
      if (val) obj[f] = val;
    });
    setUtm(obj);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    try {
      const payload = { ...form, ...utm };
      const res = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        setStatus('success');
        // dispatch custom event for analytics
        window.dispatchEvent(new CustomEvent('generate_lead', { detail: payload }));
        setForm({
          fullName: '',
          email: '',
          phone: '',
          zip: '',
          service: '',
          preferredDate: '',
          notes: '',
        });
      } else {
        setStatus('error');
      }
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="fullName">
          Full Name
        </label>
        <input
          id="fullName"
          name="fullName"
          type="text"
          value={form.fullName}
          onChange={handleChange}
          required
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          value={form.email}
          onChange={handleChange}
          required
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="phone">
          Phone
        </label>
        <input
          id="phone"
          name="phone"
          type="tel"
          value={form.phone}
          onChange={handleChange}
          required
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="zip">
          ZIP Code
        </label>
        <input
          id="zip"
          name="zip"
          type="text"
          value={form.zip}
          onChange={handleChange}
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="service">
          Service Interested In
        </label>
        <input
          id="service"
          name="service"
          type="text"
          value={form.service}
          onChange={handleChange}
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="preferredDate">
          Preferred Date
        </label>
        <input
          id="preferredDate"
          name="preferredDate"
          type="date"
          value={form.preferredDate}
          onChange={handleChange}
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="notes">
          Notes
        </label>
        <textarea
          id="notes"
          name="notes"
          value={form.notes}
          onChange={handleChange}
          rows={3}
          className="w-full border border-slate-300 rounded px-3 py-2"
        />
      </div>
      {/* Hidden utm and gclid fields for analytics */}
      {Object.entries(utm).map(([key, value]) => (
        <input key={key} type="hidden" name={key} value={value} readOnly />
      ))}
      <button
        type="submit"
        disabled={status === 'loading'}
        className="w-full py-3 rounded bg-brand-primary text-white font-medium hover:bg-brand-dark transition"
      >
        {status === 'loading' ? 'Submitting…' : 'Get My Quote'}
      </button>
      {status === 'success' && (
        <p className="text-green-700 text-sm mt-2">Thank you! We’ll be in touch shortly.</p>
      )}
      {status === 'error' && (
        <p className="text-red-700 text-sm mt-2">Oops! Something went wrong. Please try again.</p>
      )}
    </form>
  );
}