import Link from 'next/link';

export interface CTAProps {
  headline: string;
  button: string;
  href?: string;
}

/**
 * CTA is a reusable component for prompting the user to take an action.
 * It appears typically at the end of a page or section.
 */
export default function CTA({ headline, button, href = '/book' }: CTAProps) {
  return (
    <section className="bg-brand-dark text-white py-12 px-4 text-center">
      <h2 className="text-2xl md:text-3xl font-semibold mb-4">{headline}</h2>
      <Link
        href={href}
        className="inline-block bg-brand-accent text-brand-dark px-6 py-3 rounded font-medium"
      >
        {button}
      </Link>
    </section>
  );
}