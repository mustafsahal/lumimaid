export default function TrustBadges() {
  const items = [
    { label: 'Bonded & Insured' },
    { label: 'Eco‑Friendly' },
    { label: '100% Happiness Guarantee' },
  ]
  return (
    <section className="container py-8">
      <div className="flex flex-wrap gap-3">
        {items.map((b, i) => (
          <div key={i} className="px-4 py-2 border rounded-full text-sm bg-white">
            {b.label}
          </div>
        ))}
      </div>
    </section>
  )
}
