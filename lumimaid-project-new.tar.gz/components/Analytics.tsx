'use client'
import { useEffect } from 'react'

export default function Analytics() {
  useEffect(() => {
    // Google Tag Manager
    const gtm = process.env.NEXT_PUBLIC_GTM_ID
    if (gtm) {
      const s = document.createElement('script')
      s.innerHTML = `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${gtm}');`
      document.head.appendChild(s)
    }
    // GA4 basic pageview
    const ga4 = process.env.NEXT_PUBLIC_GA4_ID
    if (ga4) {
      const s = document.createElement('script')
      s.src = `https://www.googletagmanager.com/gtag/js?id=${ga4}`
      s.async = true
      document.head.appendChild(s)
      const s2 = document.createElement('script')
      s2.innerHTML = `window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', '${ga4}');`
      document.head.appendChild(s2)
    }
    // Meta Pixel
    const pixel = process.env.NEXT_PUBLIC_META_PIXEL_ID
    if (pixel) {
      const s = document.createElement('script')
      s.innerHTML = `!function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '${pixel}');
      fbq('track', 'PageView');`
      document.head.appendChild(s)
    }
  }, [])
  return null
}
