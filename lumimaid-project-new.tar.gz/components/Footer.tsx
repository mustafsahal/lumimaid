"use client";
import Link from "next/link";
import config from "@/site.config.json";

/**
 * Site footer that communicates trust, displays company info and links,
 * and provides a clear call-to-action for visitors. Includes basic
 * social icons as SVGs, and dispatches custom events for GTM when
 * users click on contact links or the CTA. Also surfaces quick
 * links to top blog posts to aid internal linking and SEO.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  const fire = (name: string, detail: any = {}) => {
    try {
      window.dispatchEvent(new CustomEvent(name, { detail }));
    } catch {
      /* server-safe */
    }
  };
  // Determine sanitized phone for tel link
  const tel = config.primaryPhone?.replace(/[^+0-9]/g, "") || "";
  // Top blog posts to promote internal linking
  const topPosts = [
    {
      href: "/blog/minneapolis-cleaning-services-pricing-2025",
      label: "Cleaning Pricing 2025",
    },
    {
      href: "/blog/best-house-cleaners-minneapolis-comparison",
      label: "Best House Cleaners",
    },
    {
      href: "/blog/minneapolis-apartment-move-out-cleaning-checklist",
      label: "Move-Out Checklist",
    },
  ];
  // Build LocalBusiness schema for SEO if needed
  const schema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: config.businessName,
    image: `https://${config.domain}/og/og-home.jpg`,
    telephone: config.primaryPhone,
    email: config.email,
    address: {
      "@type": "PostalAddress",
      streetAddress: config.address,
      addressLocality: config.city,
      addressRegion: "MN",
      postalCode: "",
      addressCountry: "US",
    },
    areaServed: config.serviceAreas,
    openingHours: config.openingHours?.replace("–", "-"),
    url: `https://${config.domain}`,
    priceRange: "$$",
  };
  return (
    <footer className="bg-brand-dark text-slate-200 py-10 px-4 md:py-14">
      {/* Inject schema for LocalBusiness; wrapped in script tag */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left column: branding and tagline */}
        <div>
          <Link href="/" className="flex items-center" aria-label="Home">
            <img
              src="/brand/logo.svg"
              alt="LumiMaid logo"
              className="h-8 w-auto"
            />
          </Link>
          <p className="mt-4 text-sm">Luxury Cleaning Minneapolis</p>
          <p className="mt-2 text-sm italic text-slate-300">
            {config.introOffer}
          </p>
        </div>
        {/* Middle column: navigation */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Company</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <Link href="/">Home</Link>
            </li>
            <li>
              <Link href="/services">Services</Link>
            </li>
            <li>
              <Link href="/about">About</Link>
            </li>
            <li>
              <Link href="/blog">Blog</Link>
            </li>
            <li>
              <Link href="/locations/minneapolis">Locations</Link>
            </li>
            <li>
              <Link href="/book">Book</Link>
            </li>
          </ul>
          {/* promote blog posts for internal linking */}
          <h3 className="text-lg font-semibold mt-6 mb-2">From the Blog</h3>
          <ul className="space-y-1 text-sm">
            {topPosts.map((post) => (
              <li key={post.href}>
                <Link href={post.href} className="underline hover:text-brand-accent">
                  {post.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        {/* Right column: contact, social and CTA */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Contact</h3>
          <p className="text-sm">
            Phone: {" "}
            <a
              href={`tel:${tel}`}
              onClick={() => fire("contact", { type: "phone", source: "footer" })}
              className="underline"
            >
              {config.primaryPhone}
            </a>
          </p>
          <p className="text-sm mt-1">
            Email: {" "}
            <a
              href={`mailto:${config.email}`}
              onClick={() => fire("contact", { type: "email", source: "footer" })}
              className="underline"
            >
              {config.email}
            </a>
          </p>
          <p className="text-sm mt-1">
            Address: {" "}
            <a
              href="https://www.google.com/maps?q=Minneapolis+MN"
              className="underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              Minneapolis, MN
            </a>
          </p>
          <p className="text-sm mt-1">Hours: {config.openingHours}</p>
          {/* Social icons */}
          <div className="mt-4 flex space-x-4">
            {/* Facebook */}
            <a href="#" aria-label="Facebook" className="hover:opacity-75">
              <svg
                width={24}
                height={24}
                fill="currentColor"
                className="text-slate-200"
              >
                <path d="M22 12c0-5.522-4.477-10-10-10S2 6.478 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54v-2.89h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.77-1.63 1.562v1.875h2.773l-.443 2.89h-2.33v6.987C18.343 21.128 22 16.991 22 12z" />
              </svg>
            </a>
            {/* Instagram */}
            <a href="#" aria-label="Instagram" className="hover:opacity-75">
              <svg
                width={24}
                height={24}
                fill="currentColor"
                className="text-slate-200"
              >
                <path d="M7 2C4.243 2 2 4.243 2 7v10c0 2.757 2.243 5 5 5h10c2.757 0 5-2.243 5-5V7c0-2.757-2.243-5-5-5H7zm10 2a3 3 0 013 3v10a3 3 0 01-3 3H7a3 3 0 01-3-3V7a3 3 0 013-3h10zm-5 3a5 5 0 100 10 5 5 0 000-10zm0 2a3 3 0 110 6 3 3 0 010-6zm4.5-.9a1.1 1.1 0 11-2.2 0 1.1 1.1 0 012.2 0z" />
              </svg>
            </a>
            {/* LinkedIn */}
            <a href="#" aria-label="LinkedIn" className="hover:opacity-75">
              <svg
                width={24}
                height={24}
                fill="currentColor"
                className="text-slate-200"
              >
                <path d="M4.984 3.5C3.882 3.5 3 4.385 3 5.5c0 1.115.881 2 1.984 2 1.103 0 1.99-.885 1.99-2 0-1.115-.887-2-1.99-2zM3 8h3.969v12H3V8zm6.406 0h3.797v1.641h.054c.528-.998 1.823-2.049 3.757-2.049 4.01 0 4.752 2.641 4.752 6.077V20H16.67v-5.273c0-1.257-.024-2.874-1.77-2.874-1.77 0-2.042 1.39-2.042 2.785V20H9.406V8z" />
              </svg>
            </a>
          </div>
          {/* CTA button */}
          <div className="mt-4">
            <Link href="/book">
              <button
                onClick={() => fire("begin_checkout", { source: "footer" })}
                className="bg-brand-primary text-white px-4 py-2 rounded-md hover:bg-brand-dark"
              >
                Get a Quote
              </button>
            </Link>
          </div>
        </div>
      </div>
      {/* Bottom bar */}
      <div className="max-w-7xl mx-auto border-t border-slate-700 mt-8 pt-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
        <div className="md:col-span-2">
          <p className="text-xs">
            &copy; {year} {config.businessName}. All rights reserved.
          </p>
        </div>
        <div className="flex flex-wrap justify-start md:justify-end space-x-3 text-xs">
          <Link href="/privacy" className="underline">
            Privacy Policy
          </Link>
          <Link href="/terms" className="underline">
            Terms
          </Link>
          <span>Bonded &amp; Insured</span>
        </div>
      </div>
    </footer>
  );
}