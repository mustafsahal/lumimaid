import site from '@/site.config.json'

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-black/5">
      <div className="container py-10 grid md:grid-cols-3 gap-8 text-sm">
        <div>
          <h3 className="font-semibold mb-2">{site.businessName}</h3>
          <p>{site.city}, Minnesota • {site.primaryPhone}</p>
          <p>{site.email}</p>
        </div>
        <div>
          <h3 className="font-semibold mb-2">Service Areas</h3>
          <ul className="grid grid-cols-2 gap-2">
            {site.serviceAreas.map((c)=>(
              <li key={c}>{c}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-semibold mb-2">Assurance</h3>
          <ul className="space-y-1">
            <li>Bonded & Insured</li>
            <li>Eco‑Friendly Products</li>
            <li>100% Happiness Guarantee</li>
          </ul>
        </div>
      </div>
      <div className="text-center text-xs pb-8 opacity-70">
        © {new Date().getFullYear()} {site.businessName}. All rights reserved.
      </div>
    </footer>
  )
}
