import Link from 'next/link';

// Simple site footer with basic info and navigation.
export default function Footer() {
  return (
    <footer className="border-t bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 py-8 grid gap-4 sm:grid-cols-3 text-sm text-slate-600">
        <div>
          <div className="font-semibold text-slate-900 mb-2">LumiMaid</div>
          <p>Minneapolis • St. Paul • Surrounding suburbs</p>
          <p>Mon–Sat 8am–6pm</p>
        </div>
        <div>
          <div className="font-semibold text-slate-900 mb-2">Company</div>
          <ul className="space-y-1">
            <li>
              <Link href="/services">Services</Link>
            </li>
            <li>
              <Link href="/locations">Locations</Link>
            </li>
            <li>
              <Link href="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div>
          <div className="font-semibold text-slate-900 mb-2">Get a Quote</div>
          <p className="mb-2">Fast, free estimate in minutes.</p>
          <Link
            href="/book"
            className="rounded bg-sky-600 px-3 py-1.5 text-white hover:bg-sky-700"
          >
            Book / Quote
          </Link>
        </div>
      </div>
    </footer>
  );
}
