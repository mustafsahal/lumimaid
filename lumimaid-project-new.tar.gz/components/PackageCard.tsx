import Link from 'next/link';

export interface PackageCardProps {
  name: string;
  promise: string;
  bullets: string[];
  priceFrom: number;
  cta: string;
  href?: string;
}

/**
 * PackageCard renders a summary of a service offering with pricing and
 * details. Used on the home and services pages.
 */
export default function PackageCard({
  name,
  promise,
  bullets,
  priceFrom,
  cta,
  href = '/book',
}: PackageCardProps) {
  return (
    <div className="flex flex-col rounded-lg border border-slate-200 p-6 shadow-sm h-full">
      <h3 className="text-xl font-semibold mb-2 text-brand-dark">{name}</h3>
      <p className="text-sm text-slate-700 mb-4 flex-grow">{promise}</p>
      <ul className="space-y-1 mb-4 text-slate-600 text-sm">
        {bullets.map((item, idx) => (
          <li key={idx} className="flex items-start gap-2">
            <span className="text-brand-primary">•</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
      <p className="text-brand-dark font-bold text-lg mb-4">From ${priceFrom}</p>
      <Link
        href={href}
        className="mt-auto inline-block text-center px-4 py-2 rounded bg-brand-primary text-white hover:bg-brand-dark transition"
      >
        {cta}
      </Link>
    </div>
  );
}