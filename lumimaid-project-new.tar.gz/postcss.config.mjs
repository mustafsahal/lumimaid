// Configure PostCSS plugins. We include Tailwind CSS, but omit
// Autoprefixer because it is not installed in production on Vercel.
// Removing the autoprefixer plugin avoids build failures when
// `autoprefixer` is not present in dependencies.
export default {
  plugins: {
    tailwindcss: {}
    // autoprefixer: {} // Autoprefixer removed to prevent build errors
  }
};