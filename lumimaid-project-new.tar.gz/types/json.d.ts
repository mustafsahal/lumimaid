// Type declaration for importing JSON modules
// This allows TypeScript to import JSON files without complaining about missing type declarations.

declare module '*.json' {
  const value: any;
  export default value;
}