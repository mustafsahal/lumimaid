import { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'What to Expect — LumiMaid',
  alternates: { canonical: `${baseUrl}/what-to-expect` }
}

export default function WhatToExpect() {
  return (
    <div className="container py-10 prose max-w-none">
      <h1 className="font-serif text-4xl">What to Expect</h1>
      <p>Here’s how we make luxury cleaning seamless from start to finish.</p>
      <h2>Arrival Window</h2>
      <p>We provide a 60–90 minute arrival window to account for routing and prior jobs.</p>
      <h2>Preparation</h2>
      <ul>
        <li>Pick up toys, clothes, and clutter where possible.</li>
        <li>Secure pets if they are nervous with visitors.</li>
        <li>Ensure access (door code, concierge, or lockbox).</li>
      </ul>
      <h2>Safety & Products</h2>
      <p>We use eco‑friendly products. If you have sensitivities, let us know and we’ll tailor accordingly.</p>
      <h2>After Your Clean</h2>
      <p>Do a walkthrough with your cleaner if you are home. We offer a 100% Happiness Guarantee—if anything was missed, we return to make it right.</p>
    </div>
  )
}
