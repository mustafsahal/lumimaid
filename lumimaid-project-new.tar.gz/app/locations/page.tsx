import Link from 'next/link';
import { cities } from '../data/cities';

export const metadata = {
  title: 'Locations | LumiMaid',
  description: 'House cleaning across Minneapolis and nearby suburbs.',
};

// This page lists all available service areas and links to each city page.
export default function LocationsPage() {
  return (
    <main className="mx-auto max-w-5xl px-4 py-12">
      <h1 className="text-3xl font-semibold mb-6">Locations We Serve</h1>
      <ul className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
        {cities.map((c) => (
          <li key={c.slug}>
            <Link href={`/locations/${c.slug}`} className="text-sky-600 hover:underline">
              House Cleaning in {c.name}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
