import { cityBySlug, citySlugs } from '../../data/cities';

export function generateStaticParams() {
  return citySlugs().map((city) => ({ city }));
}

export function generateMetadata({ params }: { params: { city: string } }) {
  const c = cityBySlug(params.city);
  const name = c?.name ?? 'Your City';
  return {
    title: `House Cleaning in ${name} | LumiMaid`,
    description: `Professional house cleaning in ${name}. Recurring, deep, and move-out services.`,
  };
}

// Page component for a single city. Shows information about services available.
export default function CityPage({ params }: { params: { city: string } }) {
  const c = cityBySlug(params.city);
  if (!c) return null;

  return (
    <main className="mx-auto max-w-5xl px-4 py-12 space-y-6">
      <h1 className="text-3xl font-semibold">House Cleaning in {c.name}</h1>
      <p className="text-slate-700">
        Premium recurring, deep, and move-out cleaning in {c.name}. Bonded, insured, and eco-friendly.
      </p>
      <ul className="list-disc pl-5 text-slate-700 space-y-1">
        <li>Recurring cleaning (weekly, bi-weekly, monthly)</li>
        <li>Deep cleaning (top-to-bottom detail)</li>
        <li>Move-in / Move-out cleaning</li>
      </ul>
      <a
        href="/book"
        className="inline-block mt-2 rounded bg-sky-600 px-4 py-2 text-white hover:bg-sky-700"
      >
        Get My Instant Quote
      </a>
    </main>
  );
}
