import fs from 'fs';
import path from 'path';
import { titleize } from '@/lib/seo';
import PackageCard from '@/components/PackageCard';
import CTA from '@/components/CTA';
import services from '@/content/services.json';

interface LocationData {
  seo: { title: string; description: string };
  headline: string;
  body: string;
  popular: string[];
  cta: string;
}

export async function generateStaticParams() {
  const locDir = path.join(process.cwd(), 'content', 'locations');
  const files = fs.readdirSync(locDir).filter((f) => f.endsWith('.json'));
  return files.map((file) => ({ city: file.replace(/\.json$/, '') }));
}

export async function generateMetadata({ params }: { params: { city: string } }) {
  const filePath = path.join(process.cwd(), 'content', 'locations', `${params.city}.json`);
  const data: LocationData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  return {
    title: titleize(data.seo.title),
    description: data.seo.description,
  };
}

export default function LocationPage({ params }: { params: { city: string } }) {
  const filePath = path.join(process.cwd(), 'content', 'locations', `${params.city}.json`);
  const data: LocationData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  // find popular packages by name from services file
  const popularServices = services.services.filter((svc) =>
    data.popular.includes(svc.name)
  );
  return (
    <main className="px-4 py-12">
      <div className="max-w-4xl mx-auto text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-semibold mb-2">{data.headline}</h1>
        <p className="text-slate-600">{data.body}</p>
      </div>
      <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {popularServices.map((svc) => (
          <PackageCard
            key={svc.slug}
            name={svc.name}
            promise={svc.promise}
            bullets={svc.benefits}
            priceFrom={svc.startingAt}
            cta={`Reserve ${svc.name.split(' ')[0]}`}
            href={`/book?service=${svc.slug}`}
          />
        ))}
      </div>
      <CTA headline={data.cta} button="Get a Quote" href="/book" />
    </main>
  );
}