import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function StLouisParkPage() {
  const city = "St. Louis Park";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Trusted ${city} house cleaning near West End, Excelsior Blvd, and Cedar Lake.`}
        canonical="https://lumimaid.com/locations/st-louis-park"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/st-louis-park" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">
          {city} House Cleaning
        </h1>
        <p className="mt-4 max-w-3xl">
          From Excelsior Boulevard homes to apartments near West End and lakefront
          houses by Cedar Lake, LumiMaid is the go-to cleaning team in {city}.
          Choose deep, move-out, or recurring packages.
        </p>
        <div className="mt-8">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you clean apartments near West End?",
              answer:
                "Yes, we handle apartments and condos throughout St. Louis Park.",
            },
            {
              question: "Is parking required?",
              answer:
                "Please provide parking instructions if your building has restrictions.",
            },
          ]}
        />
      </section>
    </>
  );
}