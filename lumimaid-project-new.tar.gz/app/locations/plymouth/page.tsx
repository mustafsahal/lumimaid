import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function PlymouthPage() {
  const city = "Plymouth";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Reliable ${city} cleaning near Medicine Lake and Plymouth Creek.`}
        canonical="https://lumimaid.com/locations/plymouth"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/plymouth" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">{city} House Cleaning</h1>
        <p className="mt-4 max-w-3xl">
          LumiMaid brings eco-friendly cleaning to Plymouth neighborhoods near
          Medicine Lake, Plymouth Creek, and Bass Lake Road.
        </p>
        <div className="mt-6">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you clean lake homes near Medicine Lake?",
              answer: "Yes, we service properties around Medicine Lake and beyond.",
            },
          ]}
        />
      </section>
    </>
  );
}