import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function RosevillePage() {
  const city = "Roseville";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Reliable ${city} house cleaning near Rosedale Center and Central Park.`}
        canonical="https://lumimaid.com/locations/roseville"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/roseville" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">{city} House Cleaning</h1>
        <p className="mt-4 max-w-3xl">
          LumiMaid serves {city} residents near Rosedale Center, Central Park, and
          homes along Snelling Avenue, offering weekly, bi-weekly, and deep
          cleans.
        </p>
        <div className="mt-6">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you service apartments near Rosedale?",
              answer:
                "Yes, LumiMaid covers apartments, condos, and single-family homes.",
            },
          ]}
        />
      </section>
    </>
  );
}