import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function BloomingtonPage() {
  const city = "Bloomington";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Professional ${city} cleaning near Mall of America, Normandale, and Hyland Lake.`}
        canonical="https://lumimaid.com/locations/bloomington"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/bloomington" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">
          {city} House Cleaning
        </h1>
        <p className="mt-4 max-w-3xl">
          Whether near Mall of America, Normandale Lake, or Hyland Park
          neighborhoods, LumiMaid provides thorough, eco-friendly cleaning for
          {city} families and professionals.
        </p>
        <div className="mt-8">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you clean near the Mall of America?",
              answer: "Yes, we cover homes and apartments throughout Bloomington.",
            },
            {
              question: "Do you offer weekend service?",
              answer: "Saturday slots are available by request.",
            },
          ]}
        />
      </section>
    </>
  );
}