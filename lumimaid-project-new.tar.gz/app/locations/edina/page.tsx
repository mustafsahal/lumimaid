import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function EdinaPage() {
  const city = "Edina";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Premium ${city} house cleaning—weekly, bi-weekly, deep clean & move-out. Bonded & insured. Book in minutes.`}
        canonical={`https://lumimaid.com/locations/edina`}
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: `https://lumimaid.com/locations/edina` },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">{city} House Cleaning</h1>
        <p className="mt-4 max-w-3xl">
          Live beautifully in {city}. LumiMaid provides premium eco-friendly
          cleanings for homes near Centennial Lakes Park, 50th &amp; France,
          and neighborhoods along Minnehaha Creek. Choose weekly, bi-weekly,
          deep cleaning, or move-out services—book in minutes.
        </p>
        <div className="mt-6 flex gap-4">
          <Link href="/services/deep-cleaning" className="underline">
            Deep Cleaning
          </Link>
          <Link href="/services/move-in-out-cleaning" className="underline">
            Move-Out Cleaning
          </Link>
          <Link href="/services/standard-cleaning" className="underline">
            Standard Cleaning
          </Link>
        </div>
        <div className="mt-8">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            { question: "Do you bring supplies?", answer: "Yes, we bring everything—eco-friendly by default." },
            { question: "Are you insured?", answer: "Yes, bonded and insured for peace of mind." },
            { question: "How long is a standard clean?", answer: "Most homes: 2–4 hours depending on size and condition." },
          ]}
        />
      </section>
    </>
  );
}