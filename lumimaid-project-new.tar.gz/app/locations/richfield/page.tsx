import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function RichfieldPage() {
  const city = "Richfield";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Eco-friendly house cleaning in ${city} near Wood Lake Nature Center and Penn Ave.`}
        canonical="https://lumimaid.com/locations/richfield"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/richfield" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">{city} House Cleaning</h1>
        <p className="mt-4 max-w-3xl">
          LumiMaid serves Richfield families near Wood Lake Nature Center, Penn
          Avenue homes, and close to the airport corridor.
        </p>
        <div className="mt-6">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you clean townhomes near Penn Ave?",
              answer: "Yes, LumiMaid covers all housing types in Richfield.",
            },
          ]}
        />
      </section>
    </>
  );
}