import SEO from "@/components/SEO";
import { BreadcrumbsSchema, FAQPageSchema } from "@/components/Schema";
import Link from "next/link";

export default function MinnetonkaPage() {
  const city = "Minnetonka";
  return (
    <>
      <SEO
        title={`House Cleaning in ${city} | LumiMaid`}
        description={`Trusted ${city} house cleaning near Ridgedale Mall and Lake Minnetonka homes.`}
        canonical="https://lumimaid.com/locations/minnetonka"
      />
      <BreadcrumbsSchema
        items={[
          { name: "Home", url: "https://lumimaid.com/" },
          { name: "Locations", url: "https://lumimaid.com/locations" },
          { name: city, url: "https://lumimaid.com/locations/minnetonka" },
        ]}
      />
      <section className="container mx-auto px-4 py-10">
        <h1 className="text-3xl md:text-4xl font-semibold">{city} House Cleaning</h1>
        <p className="mt-4 max-w-3xl">
          From lakefront homes on Minnetonka Boulevard to families near Ridgedale
          Center, LumiMaid offers detailed cleaning and eco-friendly service.
        </p>
        <div className="mt-6">
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="rounded-xl bg-black text-white px-5 py-3"
          >
            Book in {city}
          </Link>
        </div>
        <FAQPageSchema
          faq={[
            {
              question: "Do you service lakefront properties?",
              answer: "Yes, we frequently clean larger homes near Lake Minnetonka.",
            },
          ]}
        />
      </section>
    </>
  );
}