import { notFound } from 'next/navigation'
import { services } from '@/lib/services'
import { baseUrl } from '@/lib/seo'
import type { Metadata } from 'next'

type Props = { params: { slug: string } }

export function generateStaticParams() {
  return services.map(s => ({ slug: s.slug }))
}

export function generateMetadata({ params }: Props): Metadata {
  const s = services.find(x => x.slug === params.slug)
  if (!s) return {}
  return {
    title: `${s.title} — LumiMaid`,
    description: s.excerpt,
    alternates: { canonical: `${baseUrl}/services/${s.slug}` }
  }
}

export default function ServicePage({ params }: Props) {
  const s = services.find(x => x.slug === params.slug)
  if (!s) return notFound()
  return (
    <div className="container py-10">
      <h1 className="font-serif text-4xl">{s.title}</h1>
      <p className="opacity-80 mt-2">{s.excerpt}</p>
      <div className="grid md:grid-cols-3 gap-6 mt-6">
        <div className="md:col-span-2 card">
          <h2 className="font-semibold">What’s Included</h2>
          <ul className="list-disc ml-5 mt-2">
            {s.features.map(f => <li key={f}>{f}</li>)}
          </ul>
        </div>
        <aside className="card">
          <h3 className="font-semibold">Ready to book?</h3>
          <a className="btn btn-primary mt-3" href="/book-now">Book {s.title}</a>
        </aside>
      </div>
    </div>
  )
}
