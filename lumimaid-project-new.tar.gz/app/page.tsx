import React from "react";
import SEO from "@/components/SEO";
import { LocalBusinessSchema } from "@/components/Schema";
import HeroLeadForm from "@/components/HeroLeadForm";
import StickyCTA from "@/components/StickyCTA";
import InternalLinkingSection from "@/components/InternalLinkingSection";

export default function HomePage() {
  return (
    <>
      <SEO
        title="Luxury House Cleaning in Minneapolis | LumiMaid"
        description="Premium, eco-friendly weekly, bi-weekly, deep, and move-out cleaning. Bonded & insured. Book in minutes."
        canonical="https://lumimaid.com/"
      />
      <LocalBusinessSchema
        name="LumiMaid Professional Cleaning"
        phone="+1 (612) 888-7916"
        email="hello@lumimaid.com"
        url="https://lumimaid.com"
        street="123 Example Ave"
        city="Minneapolis"
        region="MN"
        postalCode="55401"
        serviceAreas={[
          "Minneapolis",
          "Edina",
          "St. Louis Park",
          "Bloomington",
          "Richfield",
          "Minnetonka",
          "Eden Prairie",
          "Plymouth",
          "Maple Grove",
          "Wayzata",
          "Roseville",
        ]}
        sameAs={[
          "https://maps.google.com/?cid=REPLACE_WITH_GBP_CID",
          "https://www.yelp.com/biz/REPLACE_YELP_SLUG",
          "https://nextdoor.com/pages/REPLACE_NEXTDOOR_SLUG",
        ]}
      />
      <section className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-5xl font-semibold">
          Luxury House Cleaning in Minneapolis
        </h1>
        <p className="mt-3 max-w-2xl">
          Premium, eco-friendly weekly, bi-weekly, deep, and move-out cleaning. Book in
          minutes.
        </p>
        <div className="mt-6">
          <HeroLeadForm />
        </div>
      </section>
      {/* Internal linking to popular services */}
      <InternalLinkingSection />
      <StickyCTA />
    </>
  );
}