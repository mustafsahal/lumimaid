import Link from 'next/link';

/**
 * Home page for LumiMaid. This page provides a high‑level overview
 * of the brand and key offerings. It includes a compelling hero
 * section, trust indicators, client testimonials, and a preview of
 * service packages. Users are encouraged to request an instant quote.
 */
export const metadata = {
  title: 'Luxury House Cleaning Minneapolis | LumiMaid',
  description:
    'Luxury cleaning that turns your home into a sanctuary in Minneapolis and the surrounding areas. Get an instant quote today.',
};

export default function HomePage() {
  return (
    <main className="max-w-5xl mx-auto px-4 py-16 space-y-20">
      {/* Hero section */}
      <section className="text-center space-y-6">
        <h1 className="text-5xl font-extrabold leading-tight">
          Luxury Cleaning That Turns Your Home Into a Sanctuary
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Experience peace, comfort, and a spotless home with LumiMaid’s
          premium cleaning services. Let us handle the details so you can
          enjoy more time and a stress‑free environment.
        </p>
        <Link
          href="/book"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors"
        >
          Get an Instant Quote
        </Link>
      </section>

      {/* Trust indicators */}
      <section className="space-y-8">
        <h2 className="text-3xl font-semibold text-center">Why Trust LumiMaid?</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Bonded">
              🛡️
            </span>
            <h3 className="mt-2 font-semibold">Bonded &amp; Insured</h3>
            <p className="text-sm text-gray-600">
              Your home is in safe hands with our fully bonded and insured team.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Eco-Friendly">
              🌿
            </span>
            <h3 className="mt-2 font-semibold">Eco‑Friendly Products</h3>
            <p className="text-sm text-gray-600">
              We use non‑toxic products that are safe for your family and pets.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Background Check">
              👩‍🔧
            </span>
            <h3 className="mt-2 font-semibold">Background‑Checked</h3>
            <p className="text-sm text-gray-600">
              Only trusted and vetted professionals enter your home.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-5xl" role="img" aria-label="Guarantee">
              ✅
            </span>
            <h3 className="mt-2 font-semibold">100% Happiness Guarantee</h3>
            <p className="text-sm text-gray-600">
              If you’re not delighted, we’ll come back and make it right.
            </p>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="space-y-6">
        <h2 className="text-3xl font-semibold text-center">What Our Clients Say</h2>
        <div className="space-y-4">
          <blockquote className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-700 italic">
              “LumiMaid transformed my Minneapolis home! Professional,
              thorough, and eco‑friendly.”
            </p>
            <footer className="mt-2 text-right text-gray-500">
              — Happy Client, Minneapolis
            </footer>
          </blockquote>
          <blockquote className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-700 italic">
              “The instant booking was easy, and the results blew me away.”
            </p>
            <footer className="mt-2 text-right text-gray-500">
              — Satisfied Customer, Edina
            </footer>
          </blockquote>
          <blockquote className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-700 italic">
              “Reliable, friendly service. My house has never looked better.”
            </p>
            <footer className="mt-2 text-right text-gray-500">
              — Loyal Client, Bloomington
            </footer>
          </blockquote>
        </div>
      </section>

      {/* Service packages */}
      <section className="space-y-8">
        <h2 className="text-3xl font-semibold text-center">Our Cleaning Packages</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow space-y-3">
            <h3 className="text-2xl font-semibold">Deep Clean</h3>
            <ul className="list-disc pl-5 space-y-1 text-gray-700">
              <li>Behind appliances, baseboards &amp; windowsills</li>
              <li>Inside cabinets &amp; closets</li>
              <li>Detailed bathroom &amp; kitchen sanitation</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg shadow space-y-3">
            <h3 className="text-2xl font-semibold">Standard Clean</h3>
            <ul className="list-disc pl-5 space-y-1 text-gray-700">
              <li>Dusting &amp; vacuuming</li>
              <li>Counters, floors &amp; bathrooms</li>
              <li>General tidying &amp; trash removal</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}