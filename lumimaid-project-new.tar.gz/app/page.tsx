import Hero from '@/components/Hero'
import ServicesGrid from '@/components/ServicesGrid'
import ComparisonTable from '@/components/ComparisonTable'
import Testimonials from '@/components/Testimonials'
import TrustBadges from '@/components/TrustBadges'
import JsonLd from '@/components/JsonLd'
import site from '@/site.config.json'
import { baseUrl } from '@/lib/seo'

export default function HomePage() {
  const ld = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": site.businessName,
    "image": `${baseUrl}/og-image.png`,
    "telephone": site.primaryPhone,
    "email": site.email,
    "address": {
      "@type": "PostalAddress",
      "addressLocality": site.city,
      "addressRegion": "MN",
      "addressCountry": "US"
    },
    "url": baseUrl,
    "areaServed": site.serviceAreas.map(c => ({ "@type": "City", "name": c })),
    "priceRange": "$$",
    "sameAs": []
  }
  return (
    <>
      <Hero />
      <TrustBadges />
      <ServicesGrid />
      <ComparisonTable />
      <Testimonials />
      <JsonLd json={ld} />
    </>
  )
}
