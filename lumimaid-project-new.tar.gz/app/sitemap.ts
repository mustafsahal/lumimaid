import type { MetadataRoute } from 'next'
import site from '@/site.config.json'
import { services } from '@/lib/services'
import { slugify } from '@/lib/utils'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = `https://${site.domain}`
  const staticPaths = [
    '', '/book-now', '/what-to-expect', '/policies-faq', '/blog', '/about-us', '/gift-cards'
  ].map(p => ({ url: base + p, lastModified: new Date(), changeFrequency: 'weekly' as const, priority: 0.7 }))

  const servicePaths = services.map(s => ({
    url: `${base}/services/${s.slug}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.7
  }))

  const areaPaths = site.serviceAreas.map(c => ({
    url: `${base}/service-areas/${slugify(c)}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.6
  }))

  return [...staticPaths, ...servicePaths, ...areaPaths]
}
