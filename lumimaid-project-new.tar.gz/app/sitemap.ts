import type { MetadataRoute } from "next";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://lumimaid.com";

  const staticRoutes = [
    "", // /
    "/services",
    "/what-to-expect",
    "/policies-faq",
    "/locations",
    "/blog",
    "/book",
    "/about",
    "/gift-cards",
  ];

  const serviceSlugs = [
    "standard-cleaning",
    "deep-cleaning",
    "move-in-out-cleaning",
    "post-construction-cleaning",
    "office-cleaning",
  ];

  const locationSlugs = [
    "minneapolis",
    "edina",
    "st-louis-park",
    "bloomington",
    "richfield",
    "minnetonka",
    "eden-prairie",
    "plymouth",
    "maple-grove",
    "wayzata",
    "roseville",
  ];

  // TODO: If using a CMS or file-based blog, fetch real slugs
  const blogSlugs: string[] = [];

  const urls: MetadataRoute.Sitemap = [
    ...staticRoutes.map((p) => ({
      url: `${base}${p}`,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: p === "" ? 1 : 0.8,
    })),
    ...serviceSlugs.map((s) => ({
      url: `${base}/services/${s}`,
      lastModified: new Date(),
      changeFrequency: "monthly",
      priority: 0.7,
    })),
    ...locationSlugs.map((l) => ({
      url: `${base}/locations/${l}`,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: 0.8,
    })),
    ...blogSlugs.map((b) => ({
      url: `${base}/blog/${b}`,
      lastModified: new Date(),
      changeFrequency: "monthly",
      priority: 0.6,
    })),
  ];

  return urls;
}