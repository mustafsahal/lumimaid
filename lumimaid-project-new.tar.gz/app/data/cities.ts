// This file defines a list of cities LumiMaid serves and helper functions to look up
// cities by slug. Only modify or extend this list if you add or remove service areas.

export const cities = [
  { slug: 'minneapolis', name: 'Minneapolis' },
  { slug: 'edina', name: 'Edina' },
  { slug: 'st-louis-park', name: 'St. Louis Park' },
  { slug: 'richfield', name: 'Richfield' },
  { slug: 'bloomington', name: 'Bloomington' },
  { slug: 'plymouth', name: 'Plymouth' },
  { slug: 'maple-grove', name: 'Maple Grove' },
  { slug: 'golden-valley', name: 'Golden Valley' },
  { slug: 'minnetonka', name: 'Minnetonka' },
  { slug: 'eden-prairie', name: 'Eden Prairie' },
  { slug: 'roseville', name: 'Roseville' },
  { slug: 'wayzata', name: 'Wayzata' },
];

// Returns the city object for a given slug, or undefined if not found.
export const cityBySlug = (slug: string) => cities.find((c) => c.slug === slug);

// Returns an array of all city slugs. Useful for static generation.
export const citySlugs = () => cities.map((c) => c.slug);