// List of cities served by LumiMaid for static location pages
export const cities = [
  { slug: 'minneapolis', name: 'Minneapolis' },
  { slug: 'edina', name: 'Edina' },
  { slug: 'st-louis-park', name: 'St. Louis Park' },
  { slug: 'richfield', name: 'Richfield' },
  { slug: 'bloomington', name: 'Bloomington' },
  { slug: 'plymouth', name: 'Plymouth' },
  { slug: 'maple-grove', name: 'Maple Grove' },
  { slug: 'golden-valley', name: 'Golden Valley' },
  { slug: 'minnetonka', name: 'Minnetonka' },
  { slug: 'eden-prairie', name: 'Eden Prairie' },
  { slug: 'roseville', name: 'Roseville' },
  { slug: 'wayzata', name: 'Wayzata' },
];

// Find a city by its slug
export const cityBySlug = (slug: string) => cities.find((c) => c.slug === slug);

// Return a list of all city slugs
export const citySlugs = () => cities.map((c) => c.slug);
