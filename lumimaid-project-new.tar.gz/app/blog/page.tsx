import { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'Blog — LumiMaid',
  alternates: { canonical: `${baseUrl}/blog` }
}

export default function BlogIndex() {
  const posts = [
    { title: '5 Reasons to Hire a Luxury Cleaning Service in Minneapolis', date: '2025-08-01' },
    { title: 'Deep Clean Checklist: The Luxe Edition', date: '2025-08-08' },
  ]
  return (
    <div className="container py-10">
      <h1 className="font-serif text-4xl mb-6">The LumiMaid Edit</h1>
      <div className="grid gap-4">
        {posts.map(p => (
          <article key={p.title} className="card">
            <h2 className="font-semibold">{p.title}</h2>
            <div className="text-xs opacity-60">{new Date(p.date).toLocaleDateString()}</div>
            <p className="mt-2 opacity-80">Coming soon.</p>
          </article>
        ))}
      </div>
    </div>
  )
}
