import { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'Gift Cards — LumiMaid',
  alternates: { canonical: `${baseUrl}/gift-cards` }
}

export default function GiftCards() {
  return (
    <div className="container py-10">
      <h1 className="font-serif text-4xl mb-4">Gift Cards</h1>
      <p className="opacity-80">Give the gift of time and a beautifully clean home. Contact us to purchase a digital gift card.</p>
      <a className="btn btn-primary mt-6" href="mailto:info@lumimaid.com">Email Us</a>
    </div>
  )
}
