import site from '@/site.config.json'
import { slugify } from '@/lib/utils'
import type { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'

type Props = { params: { city: string } }

export function generateStaticParams() {
  return site.serviceAreas.map(c => ({ city: slugify(c) }))
}

export function generateMetadata({ params }: Props): Metadata {
  const city = site.serviceAreas.find(c => slugify(c) === params.city) || 'Minneapolis'
  const title = `Cleaning Services in ${city} — LumiMaid`
  const url = `${baseUrl}/service-areas/${params.city}`
  return { title, alternates: { canonical: url } }
}

export default function CityPage({ params }: Props) {
  const city = site.serviceAreas.find(c => slugify(c) === params.city)
  if (!city) return <div className="container py-10"><h1>Area Not Found</h1></div>
  return (
    <div className="container py-10">
      <h1 className="font-serif text-4xl">Luxury Cleaning in {city}</h1>
      <p className="mt-2 opacity-80">Premium, eco‑friendly cleaning services in {city} by a bonded and insured team.</p>
      <div className="grid md:grid-cols-3 gap-6 mt-6">
        <div className="md:col-span-2 card">
          <h2 className="font-semibold">Popular Services</h2>
          <ul className="list-disc ml-5 mt-2">
            <li>Weekly & Bi‑Weekly Cleaning</li>
            <li>Deep Cleans</li>
            <li>Move‑In/Out</li>
          </ul>
          <div className="mt-6">
            <iframe
              className="w-full h-72 rounded-2xl"
              loading="lazy"
              src={`https://www.google.com/maps?q=${encodeURIComponent(city + ', MN')}&output=embed`}
              title={`Map of ${city}`}
            />
          </div>
        </div>
        <aside className="card">
          <h3 className="font-semibold">Ready to book in {city}?</h3>
          <a className="btn btn-primary mt-3" href="/book-now">Book Now</a>
        </aside>
      </div>
    </div>
  )
}
