"use client";

import Link from "next/link";
import SEO from "@/components/SEO";
import StickyCTA from "@/components/StickyCTA";

/**
 * Custom 404 page displayed when a user navigates to a non‑existent route.
 *
 * This page provides a clear error message along with actions for users
 * to return to the home page or book a cleaning. A sticky call‑to‑action
 * button is included to encourage conversions even on error pages.
 */
export default function NotFoundPage() {
  return (
    <>
      {/* SEO meta for the not‑found page */}
      <SEO
        title="Page Not Found | LumiMaid"
        description="Sorry, we couldn’t find the page you’re looking for. Book a cleaning or go back home."
        canonical="https://lumimaid.com/404"
      />
      <section className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">404 – Page Not Found</h1>
        <p className="mb-6 text-lg">
          Oops! We couldn’t find the page you were looking for.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            href="/"
            className="inline-block px-6 py-3 bg-black text-white rounded-lg hover:opacity-90 transition"
          >
            Go to Home
          </Link>
          <Link
            href={process.env.NEXT_PUBLIC_BOOKING_LINK || "/book"}
            className="inline-block px-6 py-3 bg-gray-200 text-black rounded-lg hover:bg-gray-300 transition"
          >
            Book a Cleaning
          </Link>
        </div>
      </section>
      {/* Sticky CTA to maintain conversions even on error pages */}
      <StickyCTA />
    </>
  );
}