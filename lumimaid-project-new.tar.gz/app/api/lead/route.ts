import { NextRequest, NextResponse } from 'next/server';
import { saveLead } from '@/lib/db';
import { postToCrm } from '@/lib/crm';
import { sendEmail } from '@/lib/mail';

export async function POST(req: NextRequest) {
  const data = await req.json();
  const lead = { ...data, createdAt: new Date().toISOString() };
  await saveLead(lead);
  await postToCrm(process.env.CRM_WEBHOOK_URL, lead);
  if (lead.email) {
    await sendEmail(
      process.env.RESEND_API_KEY,
      lead.email,
      'We received your LumiMaid request',
      `<p>Thanks for reaching out to LumiMaid!</p>
       <p>We’ll confirm details shortly. If you want to pick a time now, use: ${
         process.env.NEXT_PUBLIC_BOOKING_LINK || 'booking link coming soon'
       }.</p>`
    );
  }
  return NextResponse.json({ ok: true });
}