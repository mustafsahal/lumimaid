import { NextResponse } from 'next/server'
import site from '@/site.config.json'
import { leadEmail } from '@/lib/emails'

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Optional: post to CRM webhook
    const url = process.env.CRM_WEBHOOK_URL
    if (url) {
      try {
        await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      } catch (e) { /* ignore */ }
    }

    // Optional: send email via Resend
    const apiKey = process.env.RESEND_API_KEY
    if (apiKey) {
      const payload = leadEmail(body)
      try {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            from: `${site.businessName} <noreply@${site.domain}>`,
            to: [site.email],
            subject: payload.subject,
            html: payload.html,
            text: payload.text
          })
        })
      } catch (e) { /* ignore */ }
    }

    return NextResponse.json({ ok: true })
  } catch (e:any) {
    return NextResponse.json({ ok: false, error: e.message || 'Unknown error' }, { status: 400 })
  }
}
