import { Metadata } from 'next'
import JsonLd from '@/components/JsonLd'
import { baseUrl } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'Policies & FAQ — LumiMaid',
  alternates: { canonical: `${baseUrl}/policies-faq` }
}

export default function PoliciesFAQ() {
  const faq = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      { "@type": "Question", "name": "Are you bonded and insured?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. LumiMaid is fully bonded and insured for your peace of mind." } },
      { "@type": "Question", "name": "What is your cancellation policy?", "acceptedAnswer": { "@type": "Answer", "text": "Please give 24 hours’ notice to avoid a cancellation fee." } },
      { "@type": "Question", "name": "Do I need to be home?", "acceptedAnswer": { "@type": "Answer", "text": "No. Provide access details and we will take care of the rest." } }
    ]
  }
  return (
    <div className="container py-10 prose max-w-none">
      <h1 className="font-serif text-4xl">Policies & FAQ</h1>
      <h2>Cancellation</h2>
      <p>Please provide 24 hours’ notice to avoid a fee.</p>
      <h2>Guarantee</h2>
      <p>We stand behind our work. If we miss anything, we return to fix it.</p>
      <h2>FAQ</h2>
      <ul>
        <li><strong>Are you bonded and insured?</strong> Yes.</li>
        <li><strong>Do I need to be home?</strong> No, but please provide access.</li>
        <li><strong>What if I have pets?</strong> We are pet‑friendly. Let us know before your appointment.</li>
      </ul>
      <JsonLd json={faq} />
    </div>
  )
}
