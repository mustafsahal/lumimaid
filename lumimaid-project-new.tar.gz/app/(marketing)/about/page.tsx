import about from '@/content/about.json';
import { titleize } from '@/lib/seo';
import CTA from '@/components/CTA';

export const metadata = {
  title: titleize(about.seo.title),
  description: about.seo.description,
};

export default function AboutPage() {
  return (
    <main className="px-4 py-12">
      <div className="max-w-4xl mx-auto mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-semibold mb-2">{about.headline}</h1>
        <p className="text-slate-600">{about.body}</p>
      </div>
      <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        {about.badges.map((badge, idx) => (
          <div key={idx} className="text-center border border-slate-200 rounded p-4">
            <span className="text-brand-primary font-medium">{badge}</span>
          </div>
        ))}
      </div>
      <CTA headline="Experience the LumiMaid difference" button={about.cta} />
    </main>
  );
}