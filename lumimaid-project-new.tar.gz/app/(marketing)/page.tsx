import { loadConfig } from '@/lib/config';
import { localBusinessSchema } from '@/lib/schema';
import { titleize } from '@/lib/seo';
import Hero from '@/components/Hero';
import PackageCard from '@/components/PackageCard';
import Testimonial from '@/components/Testimonial';
import BeforeAfter from '@/components/BeforeAfter';
import FAQ from '@/components/FAQ';
import CTA from '@/components/CTA';
import Countdown from '@/components/Countdown';
import StickyBar from '@/components/StickyBar';
import LeadForm from '@/components/LeadForm';
import home from '@/content/home.json';
import faq from '@/content/faq.json';

export const metadata = {
  title: titleize(home.seo.title),
  description: home.seo.description,
};

export default function HomePage() {
  const cfg = loadConfig();
  const schema = localBusinessSchema(cfg);
  return (
    <main>
      {/* SEO structured data for LocalBusiness */}
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <Hero {...home.hero} />
      {/* Trust strip */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-sm font-medium text-brand-dark">
          {home.trustStrip.map((item, idx) => (
            <div key={idx} className="flex flex-col items-center">
              <span className="text-brand-primary text-2xl mb-1">✔</span>
              {item}
            </div>
          ))}
        </div>
      </section>
      {/* Packages section */}
      <section className="py-12 px-4">
        <div className="max-w-6xl mx-auto text-center mb-6">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">Our Packages</h2>
          <p className="text-slate-600">Choose the service that matches your lifestyle.</p>
        </div>
        <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {home.packages.map((pkg, idx) => (
            <PackageCard key={idx} {...pkg} />
          ))}
        </div>
      </section>
      {/* Testimonials */}
      <section className="py-12 bg-gray-50 px-4">
        <div className="max-w-6xl mx-auto text-center mb-6">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">What Our Clients Say</h2>
        </div>
        <div className="max-w-4xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {home.testimonials.map((t, idx) => (
            <Testimonial key={idx} {...t} />
          ))}
        </div>
      </section>
      {/* Before & After intro */}
      <section className="py-12 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">{home.beforeAfterIntro}</h2>
        </div>
        {/* Example before/after slider using gallery images */}
        <div className="max-w-4xl mx-auto">
          <BeforeAfter beforeSrc="/gallery/sample-1.jpg" afterSrc="/gallery/sample-2.jpg" />
        </div>
      </section>
      {/* Why Us section */}
      <section className="py-12 bg-gray-50 px-4">
        <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {home.whyUs.map((item, idx) => (
            <div key={idx} className="text-center">
              <h3 className="text-xl font-semibold mb-2 text-brand-dark">{item.title}</h3>
              <p className="text-sm text-slate-600">{item.text}</p>
            </div>
          ))}
        </div>
      </section>
      {/* Offer */}
      <section className="py-12 px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-semibold mb-4">{home.offer.headline}</h2>
        <Countdown />
        <p className="text-sm text-slate-600 mt-2">{home.offer.note}</p>
      </section>
      {/* FAQ */}
      <section className="py-12 bg-gray-50 px-4" id="faq">
        <div className="max-w-4xl mx-auto text-center mb-6">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">Frequently Asked Questions</h2>
          <p className="text-slate-600">Got questions? We’ve got answers.</p>
        </div>
        <div className="max-w-4xl mx-auto">
          <FAQ items={faq.items} />
        </div>
        <p className="text-center text-sm mt-6 text-slate-600">{home.faqCta}</p>
      </section>
      {/* Lead form CTA */}
      <section className="py-12 px-4" id="lead">
        <div className="max-w-xl mx-auto text-center mb-6">
          <h2 className="text-2xl md:text-3xl font-semibold mb-2">Ready to reclaim your time?</h2>
          <p className="text-slate-600">Fill out the form and we’ll send your custom quote.</p>
        </div>
        <div className="max-w-lg mx-auto">
          <LeadForm />
        </div>
      </section>
      <CTA headline={home.ctaFinal.headline} button={home.ctaFinal.button} />
      <StickyBar />
    </main>
  );
}