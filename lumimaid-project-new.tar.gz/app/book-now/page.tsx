import BookingWidget from '@/components/BookingWidget'
import { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'Book Now — LumiMaid',
  alternates: { canonical: `${baseUrl}/book-now` }
}

export default function BookNowPage() {
  return (
    <div className="container py-10">
      <h1 className="font-serif text-4xl mb-6">Book Your Cleaning</h1>
      <BookingWidget />
      <p className="mt-6 text-sm opacity-70">
        Don’t see your preferred time? Submit a request and we’ll do our best to accommodate.
      </p>
    </div>
  )
}
