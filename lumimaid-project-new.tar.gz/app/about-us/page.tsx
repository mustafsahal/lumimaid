import { Metadata } from 'next'
import { baseUrl } from '@/lib/seo'
import site from '@/site.config.json'

export const metadata: Metadata = {
  title: 'About Us — LumiMaid',
  alternates: { canonical: `${baseUrl}/about-us` }
}

export default function AboutUs() {
  return (
    <div className="container py-10 prose max-w-none">
      <h1 className="font-serif text-4xl">About {site.businessName}</h1>
      <p>We are a Minneapolis‑based team focused on meticulous detail and unforgettable service. Our mission is simple: create serene spaces for busy lives.</p>
      <h2>Our Promise</h2>
      <ul>
        <li>Respect for your time and home</li>
        <li>Consistent quality</li>
        <li>Clear communication</li>
      </ul>
    </div>
  )
}
