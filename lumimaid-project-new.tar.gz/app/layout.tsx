import './globals.css';
import type { ReactNode } from 'react';

/**
 * Root layout for the LumiMaid website. This file defines the global HTML
 * structure and injects structured data for search engines. The metadata
 * exported at the top provides a site-wide default title and description.
 */
export const metadata = {
  title: 'LumiMaid | Luxury Cleaning Minneapolis',
  description:
    'Luxury cleaning that turns your home into a sanctuary in the Minneapolis–St. Paul metro area.',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        {/* Structured data for local business */}
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: `{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "LumiMaid",
  "image": "https://lumimaid.com/logo.png",
  "url": "https://lumimaid.com",
  "telephone": "+1-612-888-7916",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "123 Example St",
    "addressLocality": "Minneapolis",
    "addressRegion": "MN",
    "postalCode": "55401",
    "addressCountry": "US"
  },
  "priceRange": "$$",
  "sameAs": [
    "https://www.facebook.com/lumimaid",
    "https://www.instagram.com/lumimaid"
  ],
  "serviceType": "House Cleaning",
  "areaServed": {
    "@type": "Place",
    "name": "Minneapolis–St. Paul Metro"
  }
}`,
          }}
        />
        {/* Structured data for the cleaning service offer */}
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: `{
  "@context": "https://schema.org",
  "@type": "Service",
  "serviceType": "House Cleaning",
  "provider": {
    "@type": "Organization",
    "name": "LumiMaid"
  },
  "areaServed": {
    "@type": "Place",
    "name": "Minneapolis Metro Area"
  },
  "offers": {
    "@type": "Offer",
    "url": "https://lumimaid.com/book",
    "priceCurrency": "USD"
  }
}`,
          }}
        />
        {/* Frequently asked questions structured data */}
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: `{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Are your cleaners bonded and insured?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, LumiMaid’s cleaning team is fully bonded, insured, and background-checked for your peace of mind."
      }
    },
    {
      "@type": "Question",
      "name": "Do you offer eco-friendly cleaning products?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, LumiMaid uses safe, eco-friendly, non-toxic cleaning products to protect your family, pets, and the environment."
      }
    },
    {
      "@type": "Question",
      "name": "Do you guarantee your services?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We provide a 100% Happiness Guarantee. If you are not satisfied, we will come back and re-clean free of charge."
      }
    }
  ]
}`,
          }}
        />
      </head>
      <body className="bg-gray-50 text-gray-900">
        {children}
      </body>
    </html>
  );
}