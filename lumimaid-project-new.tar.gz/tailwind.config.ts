import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          primary: "#1B4B66",
          accent: "#8FD3C9",
          dark: "#0B1F2A",
        },
      },
    },
  },
  plugins: [],
} satisfies Config;