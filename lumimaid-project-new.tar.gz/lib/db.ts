/**
 * A simple in-memory/console-based lead storage. In a production
 * environment this could be extended to write to a durable KV store
 * or database. For demonstration purposes it logs the lead to
 * console so we can verify submissions during development.
 */
export type Lead = {
  fullName: string;
  email: string;
  phone: string;
  zip?: string;
  service?: string;
  preferredDate?: string;
  notes?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  gclid?: string;
  createdAt: string;
};

export async function saveLead(lead: Lead) {
  // In a real app you might write the lead to a database. Here we just log.
  console.log('LEAD', lead);
  return { ok: true };
}