/**
 * Send a transactional email via Resend. When the API key is absent,
 * sending is skipped. This function expects Resend's standard endpoint
 * and returns a basic success object.
 */
export async function sendEmail(
  apiKey: string | undefined,
  to: string,
  subject: string,
  html: string
) {
  if (!apiKey) return { skipped: true };
  await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      from: 'LumiMaid <hello@mail.lumimaid.com>',
      to: [to],
      subject,
      html,
    }),
  });
  return { ok: true };
}