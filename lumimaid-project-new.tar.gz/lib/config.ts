import fs from 'fs';

// Define a type reflecting the shape of the site config file.
export type SiteConfig = typeof import('../site.config.json');

/**
 * Loads the site configuration from the project root. The configuration is
 * defined in site.config.json and provides business details used across
 * pages and components.
 */
export const loadConfig = (): SiteConfig => {
  const raw = fs.readFileSync('site.config.json', 'utf-8');
  return JSON.parse(raw) as SiteConfig;
};