import site from '@/site.config.json'

export const defaultTitle = `${site.businessName} — Luxury House Cleaning in ${site.city}`
export const defaultDescription = `Premium, eco‑friendly cleaning services in ${site.city} and nearby areas. Bonded, insured, and backed by our 100% Happiness Guarantee.`
export const baseUrl = `https://${site.domain}`
