/**
 * Append a standard brand suffix to a base page title. Ensures all pages
 * follow a consistent pattern for better SEO and user recognition.
 *
 * @param base The base title of the page.
 * @returns A combined title string.
 */
export function titleize(base: string) {
  return `${base} | LumiMaid — Luxury Cleaning Minneapolis`;
}