/**
 * Post a lead payload to an external CRM webhook. If no URL is provided
 * the request is skipped. In production you could customize this to match
 * the CRM's API requirements.
 */
export async function postToCrm(url: string | undefined, payload: any) {
  if (!url) return { skipped: true };
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return { ok: true };
}