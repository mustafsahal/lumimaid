import site from '@/site.config.json'

export const leadEmail = (data: any) => ({
  subject: `New cleaning request — ${data.name}`,
  text: `New lead for ${site.businessName}
Name: ${data.name}
Email: ${data.email}
Phone: ${data.phone}
Address: ${data.address}
Service: ${data.service}
Date: ${data.date}
Notes: ${data.notes || '—'}
`,
  html: `<h2>New lead for ${site.businessName}</h2>
  <p><strong>Name:</strong> ${data.name}</p>
  <p><strong>Email:</strong> ${data.email}</p>
  <p><strong>Phone:</strong> ${data.phone}</p>
  <p><strong>Address:</strong> ${data.address}</p>
  <p><strong>Service:</strong> ${data.service}</p>
  <p><strong>Date:</strong> ${data.date}</p>
  <p><strong>Notes:</strong> ${data.notes || '—'}</p>`
})
