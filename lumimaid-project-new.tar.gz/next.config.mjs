/** @type {import('next').NextConfig} */
const nextConfig = {
  images: { remotePatterns: [] },
  experimental: { mdxRs: true }
};
export default nextConfig;
