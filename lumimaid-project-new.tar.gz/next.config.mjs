/**
 * @type {import('next').NextConfig}
 *
 * Next.js configuration file for the LumiMaid project. This config
 * enables static site generation via `next export` by setting the
 * `output` mode to `export`. React strict mode is also enabled to
 * surface potential issues during development.
 */
const nextConfig = {
  output: 'export',
  reactStrictMode: true,
};

export default nextConfig;