## 2025-08-19
### Added
- robots.txt with sitemap reference
- Dynamic sitemap at /sitemap.xml via /app/sitemap.ts
- SEO component with canonical + OG/Twitter tags
- JSON-LD (LocalBusiness, FAQPage, BreadcrumbList) helpers
- Sticky CTA and Hero lead form with GTM events
- Location pages scaffolded (Edina + 9 more cities)

### Changed
- Homepage title/meta and single H1 enforcement
- Internal linking enhancements on homepage

### Fixed
- Lazy-load opportunities and next/image usage pass (reviewed)
- Ensured GTM loads from env and dataLayer events fire

### Verification
- /robots.txt and /sitemap.xml return 200
- Rich Results Test passes (LocalBusiness + FAQ)
- GA4 DebugView shows lead_form_submitted & booking_started events